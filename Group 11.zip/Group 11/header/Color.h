#pragma once

#define CreamyBlueBG {	154, 208, 200, 255} 
#define BlueButton {0, 106, 113, 255}
#define FadeBlueButton {0,128,128,255} 
#define HandleInputSpaceBG {72, 166, 167,255 }
#define MY_TURQUOIS {138,212,226,255}
#define MY_TURQUOIS2 {13,152,186, 255}
#define MAINMENUBTN {78, 167, 154, 255}
#define SMOKE { 180, 180, 180, 120 }