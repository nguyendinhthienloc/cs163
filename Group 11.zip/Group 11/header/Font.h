#pragma once

#include "raylib.h"

extern Font codeFont;
