#pragma once

void initAVLProgram();